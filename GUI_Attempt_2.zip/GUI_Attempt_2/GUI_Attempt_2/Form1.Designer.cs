﻿
namespace GUI_Attempt_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.shape_panel = new System.Windows.Forms.Panel();
            this.scroll_height = new System.Windows.Forms.VScrollBar();
            this.scroll_vert = new System.Windows.Forms.HScrollBar();
            this.rad_elipse = new System.Windows.Forms.RadioButton();
            this.rad_triangle = new System.Windows.Forms.RadioButton();
            this.rad_square = new System.Windows.Forms.RadioButton();
            this.rad_circle = new System.Windows.Forms.RadioButton();
            this.lbl_B = new System.Windows.Forms.Label();
            this.lbl_G = new System.Windows.Forms.Label();
            this.lbl_R = new System.Windows.Forms.Label();
            this.textB = new System.Windows.Forms.TextBox();
            this.textG = new System.Windows.Forms.TextBox();
            this.lbl_color = new System.Windows.Forms.Label();
            this.textR = new System.Windows.Forms.TextBox();
            this.check_fill = new System.Windows.Forms.CheckBox();
            this.lbl_height = new System.Windows.Forms.Label();
            this.lbl_width = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // shape_panel
            // 
            this.shape_panel.Location = new System.Drawing.Point(53, 52);
            this.shape_panel.Name = "shape_panel";
            this.shape_panel.Size = new System.Drawing.Size(375, 343);
            this.shape_panel.TabIndex = 0;
            this.shape_panel.Paint += new System.Windows.Forms.PaintEventHandler(this.shape_panel_Paint);
            // 
            // scroll_height
            // 
            this.scroll_height.Location = new System.Drawing.Point(431, 52);
            this.scroll_height.Name = "scroll_height";
            this.scroll_height.Size = new System.Drawing.Size(43, 343);
            this.scroll_height.TabIndex = 3;
            // 
            // scroll_vert
            // 
            this.scroll_vert.Location = new System.Drawing.Point(53, 398);
            this.scroll_vert.Name = "scroll_vert";
            this.scroll_vert.Size = new System.Drawing.Size(375, 35);
            this.scroll_vert.TabIndex = 4;
            // 
            // rad_elipse
            // 
            this.rad_elipse.AutoSize = true;
            this.rad_elipse.Location = new System.Drawing.Point(503, 372);
            this.rad_elipse.Name = "rad_elipse";
            this.rad_elipse.Size = new System.Drawing.Size(53, 17);
            this.rad_elipse.TabIndex = 27;
            this.rad_elipse.TabStop = true;
            this.rad_elipse.Text = "Elipse";
            this.rad_elipse.UseVisualStyleBackColor = true;
            // 
            // rad_triangle
            // 
            this.rad_triangle.AutoSize = true;
            this.rad_triangle.Location = new System.Drawing.Point(503, 349);
            this.rad_triangle.Name = "rad_triangle";
            this.rad_triangle.Size = new System.Drawing.Size(63, 17);
            this.rad_triangle.TabIndex = 26;
            this.rad_triangle.TabStop = true;
            this.rad_triangle.Text = "Triangle";
            this.rad_triangle.UseVisualStyleBackColor = true;
            // 
            // rad_square
            // 
            this.rad_square.AutoSize = true;
            this.rad_square.Location = new System.Drawing.Point(503, 326);
            this.rad_square.Name = "rad_square";
            this.rad_square.Size = new System.Drawing.Size(59, 17);
            this.rad_square.TabIndex = 25;
            this.rad_square.TabStop = true;
            this.rad_square.Text = "Square";
            this.rad_square.UseVisualStyleBackColor = true;
            // 
            // rad_circle
            // 
            this.rad_circle.AutoSize = true;
            this.rad_circle.Location = new System.Drawing.Point(503, 302);
            this.rad_circle.Name = "rad_circle";
            this.rad_circle.Size = new System.Drawing.Size(51, 17);
            this.rad_circle.TabIndex = 16;
            this.rad_circle.TabStop = true;
            this.rad_circle.Text = "Circle";
            this.rad_circle.UseVisualStyleBackColor = true;
            // 
            // lbl_B
            // 
            this.lbl_B.AutoSize = true;
            this.lbl_B.Location = new System.Drawing.Point(543, 164);
            this.lbl_B.Name = "lbl_B";
            this.lbl_B.Size = new System.Drawing.Size(14, 13);
            this.lbl_B.TabIndex = 24;
            this.lbl_B.Text = "B";
            // 
            // lbl_G
            // 
            this.lbl_G.AutoSize = true;
            this.lbl_G.Location = new System.Drawing.Point(543, 138);
            this.lbl_G.Name = "lbl_G";
            this.lbl_G.Size = new System.Drawing.Size(15, 13);
            this.lbl_G.TabIndex = 23;
            this.lbl_G.Text = "G";
            // 
            // lbl_R
            // 
            this.lbl_R.AutoSize = true;
            this.lbl_R.Location = new System.Drawing.Point(543, 112);
            this.lbl_R.Name = "lbl_R";
            this.lbl_R.Size = new System.Drawing.Size(15, 13);
            this.lbl_R.TabIndex = 22;
            this.lbl_R.Text = "R";
            // 
            // textB
            // 
            this.textB.Location = new System.Drawing.Point(500, 161);
            this.textB.Name = "textB";
            this.textB.Size = new System.Drawing.Size(37, 20);
            this.textB.TabIndex = 21;
            // 
            // textG
            // 
            this.textG.Location = new System.Drawing.Point(500, 135);
            this.textG.Name = "textG";
            this.textG.Size = new System.Drawing.Size(37, 20);
            this.textG.TabIndex = 20;
            // 
            // lbl_color
            // 
            this.lbl_color.AutoSize = true;
            this.lbl_color.Location = new System.Drawing.Point(500, 90);
            this.lbl_color.Name = "lbl_color";
            this.lbl_color.Size = new System.Drawing.Size(61, 13);
            this.lbl_color.TabIndex = 19;
            this.lbl_color.Text = "Enter RGB:";
            // 
            // textR
            // 
            this.textR.Location = new System.Drawing.Point(500, 109);
            this.textR.Name = "textR";
            this.textR.Size = new System.Drawing.Size(37, 20);
            this.textR.TabIndex = 18;
            // 
            // check_fill
            // 
            this.check_fill.AutoSize = true;
            this.check_fill.Location = new System.Drawing.Point(500, 51);
            this.check_fill.Name = "check_fill";
            this.check_fill.Size = new System.Drawing.Size(78, 17);
            this.check_fill.TabIndex = 17;
            this.check_fill.Text = "Fill Shape?";
            this.check_fill.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.check_fill.UseMnemonic = false;
            this.check_fill.UseVisualStyleBackColor = true;
            // 
            // lbl_height
            // 
            this.lbl_height.AutoSize = true;
            this.lbl_height.Location = new System.Drawing.Point(497, 225);
            this.lbl_height.Name = "lbl_height";
            this.lbl_height.Size = new System.Drawing.Size(38, 13);
            this.lbl_height.TabIndex = 28;
            this.lbl_height.Text = "Height";
            // 
            // lbl_width
            // 
            this.lbl_width.AutoSize = true;
            this.lbl_width.Location = new System.Drawing.Point(218, 433);
            this.lbl_width.Name = "lbl_width";
            this.lbl_width.Size = new System.Drawing.Size(35, 13);
            this.lbl_width.TabIndex = 29;
            this.lbl_width.Text = "Width";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(609, 470);
            this.Controls.Add(this.lbl_width);
            this.Controls.Add(this.lbl_height);
            this.Controls.Add(this.rad_elipse);
            this.Controls.Add(this.rad_triangle);
            this.Controls.Add(this.rad_square);
            this.Controls.Add(this.rad_circle);
            this.Controls.Add(this.lbl_B);
            this.Controls.Add(this.lbl_G);
            this.Controls.Add(this.lbl_R);
            this.Controls.Add(this.textB);
            this.Controls.Add(this.textG);
            this.Controls.Add(this.lbl_color);
            this.Controls.Add(this.textR);
            this.Controls.Add(this.check_fill);
            this.Controls.Add(this.scroll_vert);
            this.Controls.Add(this.scroll_height);
            this.Controls.Add(this.shape_panel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel shape_panel;
        private System.Windows.Forms.VScrollBar scroll_height;
        private System.Windows.Forms.HScrollBar scroll_vert;
        private System.Windows.Forms.RadioButton rad_elipse;
        private System.Windows.Forms.RadioButton rad_triangle;
        private System.Windows.Forms.RadioButton rad_square;
        private System.Windows.Forms.RadioButton rad_circle;
        private System.Windows.Forms.Label lbl_B;
        private System.Windows.Forms.Label lbl_G;
        private System.Windows.Forms.Label lbl_R;
        private System.Windows.Forms.TextBox textB;
        private System.Windows.Forms.TextBox textG;
        private System.Windows.Forms.Label lbl_color;
        private System.Windows.Forms.TextBox textR;
        private System.Windows.Forms.CheckBox check_fill;
        private System.Windows.Forms.Label lbl_height;
        private System.Windows.Forms.Label lbl_width;
    }
}

