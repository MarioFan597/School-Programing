﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI_Attempt_2
{
    public partial class Form1 : Form
    {
        int tempR = 0;
        int tempG = 0;
        int tempB = 0;
        int repaint = 1;
        Pen shapePen = new Pen(Color.AliceBlue); //for some reason it won't let me choose shape_color
        PointF[] points = new PointF[10];

        public Form1()
        {
            InitializeComponent();
        }

        private void shape_panel_Paint(object sender, PaintEventArgs e)
        {
            points[0].X = 0.1F;
            points[0].X = 90.8F;
            points[1].X = -0.1F;
            points[1].X = -90.8F;
            points[2].X = 50F;
            points[2].X = 50F;
            e.Graphics.DrawPolygon(shapePen, points);
        }
    }
}
