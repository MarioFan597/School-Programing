﻿
namespace Drawing_GUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
            this.shape_display = new System.Windows.Forms.Panel();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.scroll_vert = new System.Windows.Forms.HScrollBar();
            this.scroll_height = new System.Windows.Forms.VScrollBar();
            this.check_fill = new System.Windows.Forms.CheckBox();
            this.textR = new System.Windows.Forms.TextBox();
            this.lbl_color = new System.Windows.Forms.Label();
            this.textG = new System.Windows.Forms.TextBox();
            this.textB = new System.Windows.Forms.TextBox();
            this.lbl_R = new System.Windows.Forms.Label();
            this.lbl_G = new System.Windows.Forms.Label();
            this.lbl_B = new System.Windows.Forms.Label();
            this.lbl_width = new System.Windows.Forms.Label();
            this.lbl_height = new System.Windows.Forms.Label();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
            this.SuspendLayout();
            // 
            // fileSystemWatcher1
            // 
            this.fileSystemWatcher1.EnableRaisingEvents = true;
            this.fileSystemWatcher1.SynchronizingObject = this;
            // 
            // shape_display
            // 
            this.shape_display.Location = new System.Drawing.Point(63, 37);
            this.shape_display.Name = "shape_display";
            this.shape_display.Size = new System.Drawing.Size(381, 319);
            this.shape_display.TabIndex = 0;
            this.shape_display.Paint += new System.Windows.Forms.PaintEventHandler(this.shape_display_Paint);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(556, 215);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(85, 17);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "radioButton1";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // scroll_vert
            // 
            this.scroll_vert.Location = new System.Drawing.Point(63, 359);
            this.scroll_vert.Name = "scroll_vert";
            this.scroll_vert.Size = new System.Drawing.Size(381, 35);
            this.scroll_vert.TabIndex = 1;
            this.scroll_vert.Scroll += new System.Windows.Forms.ScrollEventHandler(this.scroll_vert_Scroll);
            // 
            // scroll_height
            // 
            this.scroll_height.Location = new System.Drawing.Point(447, 37);
            this.scroll_height.Name = "scroll_height";
            this.scroll_height.Size = new System.Drawing.Size(43, 319);
            this.scroll_height.TabIndex = 2;
            this.scroll_height.Scroll += new System.Windows.Forms.ScrollEventHandler(this.scroll_height_Scroll);
            // 
            // check_fill
            // 
            this.check_fill.AutoSize = true;
            this.check_fill.Location = new System.Drawing.Point(556, 54);
            this.check_fill.Name = "check_fill";
            this.check_fill.Size = new System.Drawing.Size(78, 17);
            this.check_fill.TabIndex = 3;
            this.check_fill.Text = "Fill Shape?";
            this.check_fill.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.check_fill.UseMnemonic = false;
            this.check_fill.UseVisualStyleBackColor = true;
            this.check_fill.CheckedChanged += new System.EventHandler(this.check_fill_CheckedChanged);
            // 
            // textR
            // 
            this.textR.Location = new System.Drawing.Point(556, 112);
            this.textR.Name = "textR";
            this.textR.Size = new System.Drawing.Size(37, 20);
            this.textR.TabIndex = 4;
            this.textR.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lbl_color
            // 
            this.lbl_color.AutoSize = true;
            this.lbl_color.Location = new System.Drawing.Point(556, 93);
            this.lbl_color.Name = "lbl_color";
            this.lbl_color.Size = new System.Drawing.Size(61, 13);
            this.lbl_color.TabIndex = 5;
            this.lbl_color.Text = "Enter RGB:";
            this.lbl_color.Click += new System.EventHandler(this.label1_Click);
            // 
            // textG
            // 
            this.textG.Location = new System.Drawing.Point(556, 138);
            this.textG.Name = "textG";
            this.textG.Size = new System.Drawing.Size(37, 20);
            this.textG.TabIndex = 6;
            this.textG.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textB
            // 
            this.textB.Location = new System.Drawing.Point(556, 164);
            this.textB.Name = "textB";
            this.textB.Size = new System.Drawing.Size(37, 20);
            this.textB.TabIndex = 7;
            this.textB.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // lbl_R
            // 
            this.lbl_R.AutoSize = true;
            this.lbl_R.Location = new System.Drawing.Point(599, 115);
            this.lbl_R.Name = "lbl_R";
            this.lbl_R.Size = new System.Drawing.Size(15, 13);
            this.lbl_R.TabIndex = 8;
            this.lbl_R.Text = "R";
            this.lbl_R.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // lbl_G
            // 
            this.lbl_G.AutoSize = true;
            this.lbl_G.Location = new System.Drawing.Point(599, 141);
            this.lbl_G.Name = "lbl_G";
            this.lbl_G.Size = new System.Drawing.Size(15, 13);
            this.lbl_G.TabIndex = 9;
            this.lbl_G.Text = "G";
            // 
            // lbl_B
            // 
            this.lbl_B.AutoSize = true;
            this.lbl_B.Location = new System.Drawing.Point(599, 167);
            this.lbl_B.Name = "lbl_B";
            this.lbl_B.Size = new System.Drawing.Size(14, 13);
            this.lbl_B.TabIndex = 10;
            this.lbl_B.Text = "B";
            // 
            // lbl_width
            // 
            this.lbl_width.AutoSize = true;
            this.lbl_width.Location = new System.Drawing.Point(237, 408);
            this.lbl_width.Name = "lbl_width";
            this.lbl_width.Size = new System.Drawing.Size(35, 13);
            this.lbl_width.TabIndex = 11;
            this.lbl_width.Text = "Width";
            // 
            // lbl_height
            // 
            this.lbl_height.AutoSize = true;
            this.lbl_height.Location = new System.Drawing.Point(493, 202);
            this.lbl_height.Name = "lbl_height";
            this.lbl_height.Size = new System.Drawing.Size(38, 13);
            this.lbl_height.TabIndex = 12;
            this.lbl_height.Text = "Height";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(556, 239);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(85, 17);
            this.radioButton2.TabIndex = 13;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "radioButton2";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(556, 262);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(85, 17);
            this.radioButton3.TabIndex = 14;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "radioButton3";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(556, 285);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(85, 17);
            this.radioButton4.TabIndex = 15;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "radioButton4";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.radioButton4);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.lbl_height);
            this.Controls.Add(this.lbl_width);
            this.Controls.Add(this.lbl_B);
            this.Controls.Add(this.lbl_G);
            this.Controls.Add(this.lbl_R);
            this.Controls.Add(this.textB);
            this.Controls.Add(this.textG);
            this.Controls.Add(this.lbl_color);
            this.Controls.Add(this.textR);
            this.Controls.Add(this.check_fill);
            this.Controls.Add(this.scroll_height);
            this.Controls.Add(this.scroll_vert);
            this.Controls.Add(this.shape_display);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.IO.FileSystemWatcher fileSystemWatcher1;
        private System.Windows.Forms.CheckBox check_fill;
        private System.Windows.Forms.VScrollBar scroll_height;
        private System.Windows.Forms.HScrollBar scroll_vert;
        private System.Windows.Forms.Panel shape_display;
        private System.Windows.Forms.Label lbl_color;
        private System.Windows.Forms.TextBox textR;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label lbl_B;
        private System.Windows.Forms.Label lbl_G;
        private System.Windows.Forms.Label lbl_R;
        private System.Windows.Forms.TextBox textB;
        private System.Windows.Forms.TextBox textG;
        private System.Windows.Forms.Label lbl_height;
        private System.Windows.Forms.Label lbl_width;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
    }
}

