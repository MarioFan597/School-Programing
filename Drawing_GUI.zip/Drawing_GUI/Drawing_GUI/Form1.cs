﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Drawing_GUI
{
    public partial class Form1 : Form
    {
        //variables
        Color shape_color = Color.Black;
        int tempR = 0;
        int tempG = 0;
        int tempB = 0;
        int repaint = 1;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void scroll_height_Scroll(object sender, ScrollEventArgs e)
        {
        }

        private void scroll_vert_Scroll(object sender, ScrollEventArgs e)
        {

        }

        private void shape_display_Paint(object sender, PaintEventArgs e)
        {
            if (repaint == 1)
            {
                Pen shapePen = new Pen(shape_color);
                e.Graphics.DrawLine(shapePen, 0, 0, 255, 255);
                repaint = 0;
            }
        }

        private void check_fill_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e) //Red textbox
        {
            try 
            { 
                tempR = Int32.Parse(textR.Text);
            }
            catch (Exception formatexception)
            {
                
            }
            repaint = 1;
        }

        private void textBox2_TextChanged(object sender, EventArgs e) //Green textbox
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e) //Bule textbox
        {

        }
    }
}
